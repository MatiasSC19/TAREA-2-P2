package com.example.tareamatias;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class Prueba extends AppCompatActivity {

    private EditText txtCliente;
    private EditText txtListado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txtCliente = findViewById(R.id.txtCliente);
        txtListado = findViewById(R.id.txtListado);

        findViewById(R.id.btnGuardar).setOnClickListener(this::guardar);

        findViewById(R.id.btnVerClientes).setOnClickListener(this::leer);
    }

    public void guardar(View vista) {
        String texto = txtCliente.getText().toString() + "\n";
        FileOutputStream file = null;

        try {
            file = openFileOutput("clientes.txt", MODE_APPEND);
            file.write(texto.getBytes());
            txtCliente.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void leer(View vista) {
        FileInputStream file = null;

        try {
            file = openFileInput("clientes.txt");
            InputStreamReader leerFile = new InputStreamReader(file);
            BufferedReader bufferLeer = new BufferedReader(leerFile);
            StringBuilder parrafo = new StringBuilder();
            String linea;

            while ((linea = bufferLeer.readLine()) != null) {
                parrafo.append(linea).append('\n');
            }

            txtListado.setText(parrafo.toString());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
